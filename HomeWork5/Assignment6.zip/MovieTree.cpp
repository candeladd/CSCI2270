#include <iostream>
#include <string.h>
#include "MovieTree.h"

using namespace std;

MovieTree::MovieTree(){
    opCount = 0;

    //json_object *jobject1 = json_object_new_object();
    //Assignment6Output= jobject1;
    root = NULL;
}



 MovieNode* MovieTree::searchMovieTree(MovieNode * node, std::string title, json_object * jarr){

    MovieNode* x = node;


    if(x==NULL){
        cout << "Movie not found."<< endl;
        return x;
    }
    else{

        if(strcmp(title.c_str(),x->title.c_str())==0){
            json_object *arrtitle = json_object_new_string(x->title.c_str());
            json_object_array_add(jarr, arrtitle);
                return x;
        }
        else if(strcmp(title.c_str(),x->title.c_str())>0){
            json_object *arrtitle = json_object_new_string(x->title.c_str());
            json_object_array_add(jarr, arrtitle);
            return searchMovieTree(x->rightChild, title, jarr);
        }
        else{
            json_object *arrtitle = json_object_new_string(x->title.c_str());
            json_object_array_add(jarr, arrtitle);
            return searchMovieTree(x->leftChild, title, jarr);
        }

    }
 }



void MovieTree::printMovieInventory(MovieNode * node, json_object * jarr){
    if(node->leftChild != NULL){
        printMovieInventory(node->leftChild, jarr);

    }
    cout << "Movie: "<<node->title << endl;
        json_object *arrtitle = json_object_new_string(node->title.c_str());
        json_object_array_add(jarr, arrtitle);
    if (node->rightChild != NULL){
         printMovieInventory(node->rightChild, jarr);

    }
}

void MovieTree::printMovieInventory(){
    json_object *jarr = json_object_new_array();

    printMovieInventory(root, jarr);

    opCount++;

    json_object *jopCount = json_object_new_object();

    json_object *jtravese = json_object_new_string("traverse");


    json_object_object_add(jopCount, "operation",jtravese);

    json_object_object_add(jopCount, "output", jarr);

    json_object_object_add(Assignment6Output, to_string(opCount).c_str(), jopCount);

}

int MovieTree::countMovieNodes(){
    int ccount = 0;
    ccount = countMovieNodes(root);

    opCount++;
    string counter2 = to_string(opCount);
    string counting = to_string(ccount);

    json_object *jopCount = json_object_new_object();

    json_object *jCount = json_object_new_string("count");

    json_object_object_add(jopCount, "operation",jCount);
    json_object *jtitle = json_object_new_string(counting.c_str());
    json_object_object_add(jopCount, "output", jtitle);
    json_object_object_add(Assignment6Output, counter2.c_str(), jopCount);
    return ccount;
}

int MovieTree::countMovieNodes(MovieNode* root){

    if(root!=NULL){
        return 1+countMovieNodes(root->leftChild)+countMovieNodes(root->rightChild);
    }
    return 0;
}

void MovieTree::initJson(){
 Assignment6Output = json_object_new_object();
}

void MovieTree::addMovieNode(int ranking, std::string title, int releaseYear, int quantity){

    json_object *jarr = json_object_new_array();

   // MovieNode* currentMovie =new MovieNode(ranking, title, releaseYear, quantity);

    MovieNode* x = root;
    MovieNode* P = NULL;
    while (x != NULL){
       P=x;

        json_object *arrtitle = json_object_new_string(x->title.c_str());

        json_object_array_add(jarr, arrtitle);

       if (strcmp(title.c_str(),x->title.c_str()) >=0){// go right since the first being greater than the second means that the first has a hights ascii value as in lower further in the alphabet
            x=x->rightChild;
        }
        else{// got left
            x=x->leftChild;
        }

    }
    x= new MovieNode;
    x->quantity = quantity;
    x->ranking = ranking;
    x->title = title;
    x->year = releaseYear;

    x->parent = P;
    x->leftChild =NULL;
    x->rightChild =NULL;


    //currentMovie->parent = P;

    if (P==NULL){
        root = x;


    }
    else if (strcmp (x->title.c_str(),P->title.c_str()) >= 0){
        P->rightChild = x;
    }
    else {
        P->leftChild = x;
    }
    opCount++;


    json_object *jopCount = json_object_new_object();
    json_object *jadd = json_object_new_string("add");
    json_object *jparam = json_object_new_string(title.c_str());

    json_object_object_add(jopCount, "operation",jadd);
    json_object_object_add(jopCount, "parameter",jparam);
    json_object_object_add(jopCount, "output", jarr);

    json_object_object_add(Assignment6Output, to_string(opCount).c_str(), jopCount);


}

/*void MovieTree::findMovie(std::string title){
    MovieNode* y = new MovieNode;
    json_object *jarr = json_object_new_array();
    y = searchMovieTree(root, title, jarr);
    if (y!=NULL){
        cout <<	"Movie Info:"	<<	endl;
        cout <<	"===========" << endl;
        cout <<	"Ranking:"	<< y->ranking	<<	endl;
        cout <<	"Title:" << y->title	<<	endl;
        cout <<	"Year:" <<	y->year	<<	endl;
        cout <<	"Quantity:" <<	y->quantity	<<	endl;
    }

}*/



void MovieTree::rentMovie(std::string title){
    MovieNode* y;

    json_object *jarr = json_object_new_array();
    y = searchMovieTree(root, title, jarr);
    if (y==NULL){

        return;
    }

    if ((y!=NULL)&&(y->quantity!=0)){
            y->quantity=y->quantity-1;
        cout << "Movie has been rented." <<	endl;
        cout <<	"Movie Info:" << endl;
        cout <<	"===========" << endl;
        cout <<	"Ranking:" << y->ranking << endl;
        cout <<	"Title:" << y->title << endl;
        cout <<	"Year:"	<<	y->year << endl;
        cout <<	"Quantity:"	<< y->quantity << endl;

    }


    opCount++;
    json_object *jopCount = json_object_new_object();
    json_object *jrent = json_object_new_string("rent");
    json_object *jparam = json_object_new_string(title.c_str());
    json_object *jInt = json_object_new_string(to_string(y->quantity).c_str());

    json_object_object_add(jopCount, "operation",jrent);
    json_object_object_add(jopCount, "parameter",jparam);
    json_object_object_add(jopCount, "output", jInt);

    json_object_object_add(Assignment6Output, to_string(opCount).c_str(), jopCount);
      if((y->quantity == 0)&&(y!=NULL)){
            deleteMovieNode(y->title);
        }

}


void MovieTree::deleteMovieNode(std::string title)
{
    json_object *jarr = json_object_new_array();
     // call to search function to find the node to be deleted */
    MovieNode *x, *xsucc ;





        x = searchMovieTree(root, title, jarr);


    if (x == NULL){
            return;
    }

    // if the node to be deleted has two children */
    else if ( (x -> leftChild != NULL) && (x -> rightChild != NULL) )
        {
            xsucc = x -> rightChild ;

        while ( xsucc -> leftChild != NULL )
        {
            xsucc = xsucc -> leftChild ;
        }
         if ( (xsucc->rightChild != NULL)&& (xsucc->parent->rightChild == xsucc)){
            x->quantity = xsucc->quantity;
            x->ranking = xsucc->ranking;
            x->title = xsucc->title;
            x->year = xsucc->year;

            xsucc->parent->rightChild = xsucc->rightChild;
            xsucc->rightChild->parent = xsucc->parent;
        }
        else if((xsucc->rightChild == NULL) && (xsucc->parent->rightChild == xsucc)){
            x->quantity = xsucc->quantity;
            x->ranking = xsucc->ranking;
            x->title = xsucc->title;
            x->year = xsucc->year;

            x->rightChild =NULL;

        }
        else if((xsucc->rightChild != NULL)&&(xsucc->parent->leftChild == xsucc))
        {
            x->quantity = xsucc->quantity;
            x->ranking = xsucc->ranking;
            x->title = xsucc->title;
            x->year = xsucc->year;

            xsucc->parent->leftChild = xsucc->rightChild;
            xsucc->rightChild->parent = xsucc->parent;

        }
        else {
            x->quantity = xsucc->quantity;
            x->ranking = xsucc->ranking;
            x->title = xsucc->title;
            x->year = xsucc->year;

            xsucc->parent->leftChild = NULL;

        }
        delete xsucc;
    }

    // if the node to be deleted has no child */
    else if ( x -> leftChild == NULL && x -> rightChild == NULL )
        {
        if (strcmp(x->title.c_str(),x->parent->title.c_str())>0){
            x->parent->rightChild = NULL;
        }
        else {
            x->parent->leftChild = NULL;


        }

            delete x;
        }

    // if the node to be deleted has only rightchild */
    else if ( x -> leftChild == NULL && x -> rightChild != NULL )
        {

            if (strcmp(x->title.c_str(),x->parent->title.c_str())>0){
                x->parent->rightChild = x->rightChild;
                x->rightChild->parent = x->parent;
            }
            else {
                x->parent->leftChild = x->rightChild;
                x->rightChild->parent = x->parent;

            }
            delete x;
        }

    // if the node to be deleted has only left child */
    else if ( x -> leftChild != NULL && x -> rightChild == NULL )
    {
        if (strcmp(x->title.c_str(),x->parent->title.c_str())>0){
            x->parent->rightChild = x->leftChild;
            x->leftChild->parent = x->parent;
        }
        else {
            x->parent->leftChild = x->leftChild;
            x->leftChild->parent = x->parent;

        }
        delete x;
    }
     opCount++;


    json_object *jopCount = json_object_new_object();
    json_object *jdelete = json_object_new_string("delete");
    json_object *jparam = json_object_new_string(title.c_str());

    json_object_object_add(jopCount, "operation",jdelete);
    json_object_object_add(jopCount, "parameter",jparam);
    json_object_object_add(jopCount, "output", jarr);

    json_object_object_add(Assignment6Output, to_string(opCount).c_str(), jopCount);

}

json_object* MovieTree::getJsonObject()
{
    return Assignment6Output;
}



void MovieTree::DeleteAll(MovieNode * node){
    MovieNode *x = node;

if(x->leftChild != NULL)

   DeleteAll(x->leftChild);

if(x->rightChild != NULL)

   DeleteAll(x->rightChild);
}
