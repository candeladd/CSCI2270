#include <iostream>
#include <string.h>
#include "MovieTree.h"

using namespace std;

MovieTree::MovieTree(){
    root = NULL;
}

 MovieNode* MovieTree::searchMovieTree(MovieNode* node, std::string title){
    MovieNode* x = node;
    if(x==NULL){
        cout << "Movie not found."<< endl;
    }
    else{

        if(strcmp(title.c_str(),x->title.c_str())==0){
                return x;
        }
        else if(strcmp(title.c_str(),x->title.c_str())>0){

            return searchMovieTree(x->rightChild, title);
        }
        else{
            return searchMovieTree(x->leftChild, title);
        }

    }
}



void MovieTree::printMovieInventory(MovieNode* root){
    if(root->leftChild != NULL){
        printMovieInventory(root->leftChild);
    }
    cout << "Movie: "<<root->title << endl;
    if (root->rightChild != NULL){
        printMovieInventory(root->rightChild);
    }
}
void MovieTree::printMovieInventory(){
    printMovieInventory(root);
}

void MovieTree::addMovieNode(int ranking, std::string title, int releaseYear, int quantity){

     MovieNode* currentMovie =new MovieNode(ranking, title, releaseYear, quantity);

    MovieNode* x = root;
    MovieNode* P = NULL;
    while (x != NULL){
       P=x;
       if (strcmp(currentMovie->title.c_str(),x->title.c_str()) >=0){// go right since the first being greater than the second means that the first has a hights ascii value as in lower further in the alphabet
            x=x->rightChild;

        }
        else{// got left
            x=x->leftChild;
        }

    }

    currentMovie->parent = P;

    if (P==NULL){
        root = currentMovie;


    }
    else if (strcmp (currentMovie->title.c_str(),P->title.c_str()) >= 0){
        P->rightChild = currentMovie;
    }
    else {
        P->leftChild = currentMovie;
    }
}

void MovieTree::findMovie(std::string title){
    MovieNode* y = new MovieNode;
    y = searchMovieTree(root, title);
    if (y!=NULL){
        cout <<	"Movie Info:"	<<	endl;
        cout <<	"===========" << endl;
        cout <<	"Ranking:"	<< y->ranking	<<	endl;
        cout <<	"Title:" << y->title	<<	endl;
        cout <<	"Year:" <<	y->year	<<	endl;
        cout <<	"Quantity:" <<	y->quantity	<<	endl;
    }

}



void MovieTree::rentMovie(std::string title){
    MovieNode* y = new MovieNode;
    y = searchMovieTree(root, title);
    if ((y!=NULL)&&(y->quantity!=0)){
            y->quantity=y->quantity-1;
        cout << "Movie has been rented." <<	endl;
        cout <<	"Movie Info:" << endl;
        cout <<	"===========" << endl;
        cout <<	"Ranking:" << y->ranking << endl;
        cout <<	"Title:" << y->title << endl;
        cout <<	"Year:"	<<	y->year << endl;
        cout <<	"Quantity:"	<< y->quantity << endl;
    }
    else if((y->quantity == 0)&&(y!=NULL)){
        cout <<	"Movie out of stock." << endl;
    }
}


