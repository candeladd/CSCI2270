#include <iostream>
#include <fstream>
#include <string>
#include "MovieTree.h"

using namespace std;



int main (int argc, char* argv[]){
    char* filename = argv[1];
    ifstream infile;            //ifstream reads in a file

    infile.open(filename);
    string userinput;
    MovieTree* chicken = new MovieTree();

    while(!infile.eof()){

        string temprating;
        string title;
        string tempyear;
        string tempquantity;

        getline(infile, temprating,',');//getline says to read from infile, look for type, and go until ','

        getline(infile, title,',');
        getline(infile, tempyear, ',');

        getline(infile, tempquantity);

        int rating1 = atoi(temprating.c_str());
        int year1 = atoi(tempyear.c_str());
        int quantity1 = atoi(tempquantity.c_str());


        chicken->addMovieNode(rating1, title, year1, quantity1);

    }
    while (userinput != "4"){
        cout	<<	"======Main Menu====="	<<	endl;
        cout	<<	"1. Find a movie"	<<	endl;
        cout	<<	"2. Rent a movie"	<<	endl;
        cout	<<	"3. Print the inventory"	<<	endl;
        cout	<<	"4. Quit"	<<	endl;

        getline(cin, userinput);

        if (userinput == "1"){
            cout	<<	"Enter title:"	<<	endl;
            string userinput2;
            getline(cin, userinput2);
            chicken->findMovie(userinput2);


        }
        else if(userinput == "2"){
            cout	<<	"Enter title:"	<<	endl;
            string userinput2;
            getline(cin, userinput2);
            chicken->rentMovie(userinput2);
        }
        else if(userinput == "3"){
            chicken->printMovieInventory();

        }


    }
    cout << "Goodbye!" << endl;




}
